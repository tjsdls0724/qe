//모달창 
function chkDetail1(){
    $("#agreeModal1").show();
}

function allchkContentclose(){
    $('#agreeModal1').css("display",'none');
}

